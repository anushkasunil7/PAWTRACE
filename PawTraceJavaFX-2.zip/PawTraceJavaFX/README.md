# PawTrace JavaFX

JavaFX desktop version of the PawTrace Lost & Found Pets website.

## Requirements
- JDK 17+
- Maven 3.9+

## Run
From this folder:

```bash
mvn clean javafx:run
```

The application opens maximized.

## Structure
- `src/main/java/com/pawtrace/Main.java` — JavaFX application and WebView
- `src/main/resources/web/index.html` — PawTrace UI
- `src/main/resources/web/styles.css` — responsive styling
- `src/main/resources/web/app.js` — navigation, search, filters, forms and confirmation dialogs

The pet images currently use the same remote image URLs as the supplied website.

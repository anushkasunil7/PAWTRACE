package com.pawtrace;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage stage) {
        WebView webView = new WebView();
        webView.setContextMenuEnabled(false);

        WebEngine engine = webView.getEngine();
        engine.setJavaScriptEnabled(true);

        var page = getClass().getResource("/web/index.html");
        if (page == null) {
            throw new IllegalStateException("web/index.html was not found.");
        }

        engine.load(page.toExternalForm());

        stage.setTitle("PawTrace — Lost & Found Pets");
        stage.setMinWidth(900);
        stage.setMinHeight(650);

        Scene scene = new Scene(webView, 1440, 900);
        stage.setScene(scene);

        // Start maximized so the PawTrace UI fills the screen.
        stage.setMaximized(true);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

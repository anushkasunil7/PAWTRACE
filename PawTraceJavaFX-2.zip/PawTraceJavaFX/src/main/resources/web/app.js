const pages=[...document.querySelectorAll('.page')];
function go(id){
  pages.forEach(p=>p.classList.toggle('active',p.id===id));
  document.querySelectorAll('nav a').forEach(a=>a.classList.remove('active'));
  const link=[...document.querySelectorAll('nav a')].find(a=>a.getAttribute('onclick')?.includes("'"+id+"'"));
  if(link) link.classList.add('active');
  document.querySelector('nav')?.classList.remove('mobile-open');
  window.scrollTo({top:0,behavior:'smooth'});
}
function toggleMenu(){document.querySelector('nav').classList.toggle('mobile-open')}
function toast(m,title='Success'){
  const t=document.getElementById('toast');
  document.getElementById('toastTitle').textContent=title;
  document.getElementById('toastMessage').textContent=m;
  t.classList.add('show');
}
function hideToast(e){
  if(e && e.target!==e.currentTarget)return;
  document.getElementById('toast').classList.remove('show');
}
function globalSearch(){
  const q=document.getElementById('globalSearch').value.trim();
  if(!q){go('lost');return}
  go('lost');
  const input=document.getElementById('lostSearch'); input.value=q; filterCards('lost');
}
function filterCards(kind){
  const page=document.getElementById(kind);
  if(!page)return;
  const search=(document.getElementById(kind==='lost'?'lostSearch':'foundSearch')?.value||'').toLowerCase().trim();
  const type=(document.getElementById(kind==='lost'?'typeFilter':'foundTypeFilter')?.value||'All Types').toLowerCase();
  const location=(document.getElementById(kind==='lost'?'locationFilter':'foundLocationFilter')?.value||'All Locations').toLowerCase();
  const cards=[...page.querySelectorAll('[data-pet-card]')];
  let shown=0;
  cards.forEach(card=>{
    const text=card.innerText.toLowerCase();
    const typeOk=type==='all types'||(type==='dogs'?text.includes('dog'):text.includes('cat'));
    const locOk=location==='all locations'||text.includes(location);
    const searchOk=!search||text.includes(search);
    const ok=typeOk&&locOk&&searchOk;
    card.style.display=ok?'':'none'; if(ok)shown++;
  });
  let empty=page.querySelector('.empty');
  if(!shown){
    if(!empty){empty=document.createElement('div');empty.className='empty';empty.textContent='No pets match your search or filters.';page.querySelector('.cards')?.appendChild(empty)}
    empty.style.display='';
  }else if(empty) empty.style.display='none';
}
document.addEventListener('DOMContentLoaded',()=>go('home'));